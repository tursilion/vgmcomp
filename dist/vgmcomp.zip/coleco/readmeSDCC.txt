This code was compiled and tested with SDCC 3.4.0. I had more than one issue with bad code, but this version appears to work. YMMV.

The demo was tested on BlueMSX and hardwards, and intended to run with my libti99, ported to the Coleco, which is probably not super useful to anyone but me, but, if you want it, it's on github at http://github.com/tursilion/libti99coleco 

The player routines should work fine regardless what libs you use.
