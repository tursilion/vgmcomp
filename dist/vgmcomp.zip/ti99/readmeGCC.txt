Playback routines for gcc are included in my libti99, available at https://github.com/tursilion/libti99

Those libs have had a lot more testing! :)
