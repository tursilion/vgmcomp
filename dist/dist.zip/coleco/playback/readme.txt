Unlike the TI version, separate headers are not used for the different playback routines.

To enable sound effects functions, use -DENABLEFX on your compilation line.
To enable 30hz playback instead of 60hz, use -DRUN30HZ on your compilation line.

Otherwise, usage is the same as the TI version, see playback.txt in the docs folder.
