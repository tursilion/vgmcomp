Compiling this will require my libti99 for Coleco from http://github.com/tursilion/libti99coleco
